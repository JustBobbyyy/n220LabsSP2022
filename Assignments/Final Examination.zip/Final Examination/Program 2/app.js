//Bobby Ezenwelu
//n220
//2/23/2022
//Final Examination Program 2

//create a div and bring out that div onto here, the javascript
let numbersDiv= document.getElementById("numbers");
let coolDiv= document.getElementById("cool");


// create aan array and within that array have the number "1000" in it
let integers=[1000];
integers.onclick= integers
console.log(integers);


// create a loop where it will bring out the the things in the array onto the screen
for(let i =0; i< integers.length; i++){
    coolDiv.innerHTML += integers [i] + " ";
    
};

function numbers(){

}
